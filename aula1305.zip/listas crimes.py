lista = ["telefonou para a vitima? ", "Esteve no local do crime? ", "mora perto da vitima?", "devia para a vitima? ", "já trabalhou com a vitima ? "]


respostas = []
soma_respostas = 0

for lis in range (len(lista)):
    print(lista[lis])
    respostas.append(input())
    soma_respostas += int(respostas[lis])

    if (soma_respostas >=2):
        print("suspeito")
    elif (soma_respostas >=3 and soma_respostas <=4):
        print("cumplice")
    elif (soma_respostas >4 ):
        print("assassino")







exit = input("digite algo para sair")

