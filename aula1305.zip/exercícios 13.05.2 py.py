tb = int(input("digite a tabuada que você quer ver: "))
for cont in range(0,11):
    print(tb*cont)
    print()


exit = input("digite algo para sair ")
    