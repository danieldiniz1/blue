a = [32,44,88,321,201,984,365,258,4564]
b = [21,5454,8787,1254,54564,45454,2123,]
mista = a+b

a.sort()
print(a)
b.sort()
print(b)
print(a+b)
mista.sort()
print(mista)


for nm in mista:
    print(nm)

exit = input("digite algo para fechar")