precopao = float(input("digite o preço do pão"))

for cont in range(1,51):
    print("quantidade-R$",(cont,precopao*cont))
    print()



exit = input("digite algo para fechar: ")
